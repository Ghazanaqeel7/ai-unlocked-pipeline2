# START HERE: Setup Guide

Free pack from AI Graphic TV (@AIGraphicTV). 25 starter n8n workflows.

## 1. Get n8n
Use n8n Cloud (free trial at the time of writing) or self-host the free Community Edition.

## 2. Import a workflow
Open a workflow, then the menu, Import from File, choose a JSON from `workflows/`.

## 3. Add credentials
Open the OpenAI Chat Model node, Create New Credential, paste your API key. Do the same for Gmail, Slack or Google Sheets nodes if the workflow uses them. Never share your keys.

## 4. Replace placeholders
Search each workflow for: `you@example.com`, `CHANNEL_ID`, `SHEET_ID`, `https://example.com`. Put in your own values.

## 5. Test by hand
Click Execute Workflow. Open each node and read its output. Manual runs do not count toward your execution quota.

## 6. Publish
Saving is not enough. Publish the workflow so triggers and schedules run on their own.

## Notes
- Node versions and option labels change between n8n releases. If a node shows a warning, open it and re-select the options.
- Workflows are imported inactive. Check every node before you publish.
- These are starting points, not finished products. Keep your first automation small.

Watch the full build: youtube.com/@AIGraphicTV
